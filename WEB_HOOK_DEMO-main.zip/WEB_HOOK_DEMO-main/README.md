# WEB_HOOK_DEMO
WEB HOOK demo using local server...*(Educational purpose)
[What is WEB HOOK?](https://www.redhat.com/en/topics/automation/what-is-a-webhook)

